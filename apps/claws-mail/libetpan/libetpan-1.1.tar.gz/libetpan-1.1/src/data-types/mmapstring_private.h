#ifndef MMAPSTRING_PRIVATE_H

#define MMAPSTRING_PRIVATE_H

extern void mmapstring_init_lock(void);

#endif
