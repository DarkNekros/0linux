#ifndef MAILSTREAM_SSL_PRIVATE_H

#define MAILSTREAM_SSL_PRIVATE_H

extern void mailstream_ssl_init_lock(void);

#endif
